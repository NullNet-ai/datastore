-- Custom SQL migration file, put your code below! --
-- Hypertable Creation Queries
SELECT create_hypertable('packets', 'timestamp', chunk_time_interval => INTERVAL '7 days', if_not_exists => TRUE);
