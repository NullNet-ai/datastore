CREATE TABLE "config_sync" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"type" text,
	"value" text
);
--> statement-breakpoint
CREATE TABLE "contact_emails" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"contact_id" text,
	"email" text
);
--> statement-breakpoint
CREATE TABLE "contact_phone_numbers" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"contact_id" text,
	"phone_number_raw" text
);
--> statement-breakpoint
CREATE TABLE "contacts" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"first_name" text,
	"middle_name" text,
	"last_name" text,
	"date_of_birth" text
);
--> statement-breakpoint
CREATE TABLE "organization_contact_accounts" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text,
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"organization_contact_id" text,
	"email" text,
	"password" text
);
--> statement-breakpoint
CREATE TABLE "organization_contacts" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text,
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"contact_id" text
);
--> statement-breakpoint
CREATE TABLE "organization_domains" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text,
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"domain_name" text,
	CONSTRAINT "organization_domains_domain_name_unique" UNIQUE("domain_name")
);
--> statement-breakpoint
CREATE TABLE "organization_files" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"organizaion_id" text,
	"organization_contact_id" text,
	"url" text,
	"name" text,
	"mime_type" text,
	"size" text,
	"type" text
);
--> statement-breakpoint
CREATE TABLE "organizations" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"parent_organization_id" text DEFAULT (null),
	"name" text
);
--> statement-breakpoint
CREATE TABLE "config_applications" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"type" text,
	"value" text
);
--> statement-breakpoint
CREATE TABLE "class_types" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"type" text,
	"company" text,
	"entity" text,
	"is_list" boolean DEFAULT false,
	"is_with_version" boolean DEFAULT false,
	"schema_version" text
);
--> statement-breakpoint
CREATE TABLE "fields" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"label" text,
	"name" text,
	"type" text,
	"assigned_to" text
);
--> statement-breakpoint
CREATE TABLE "allowed_fields" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"label" text,
	"name" text,
	"type" text,
	"class_type_id" text,
	"is_optional" boolean DEFAULT false,
	"is_primary_key" boolean DEFAULT false,
	"reference_to" text,
	"data_type" text,
	"default_value" text
);
--> statement-breakpoint
CREATE TABLE "counters" (
	"entity" text PRIMARY KEY NOT NULL,
	"default_code" integer DEFAULT 0,
	"prefix" text DEFAULT 'CTR',
	"counter" integer DEFAULT 0
);
--> statement-breakpoint
CREATE TABLE "crdt_merkles" (
	"group_id" text PRIMARY KEY NOT NULL,
	"timestamp" text NOT NULL,
	"merkle" text NOT NULL,
	CONSTRAINT "crdt_merkles_group_id_unique" UNIQUE("group_id")
);
--> statement-breakpoint
CREATE TABLE "crdt_messages" (
	"database" text,
	"dataset" text NOT NULL,
	"group_id" text NOT NULL,
	"timestamp" text NOT NULL,
	"row" text NOT NULL,
	"column" text NOT NULL,
	"client_id" text NOT NULL,
	"value" text NOT NULL,
	"hypertable_timestamp" text,
	CONSTRAINT "crdt_messages_timestamp_group_id_row_column_pk" PRIMARY KEY("timestamp","group_id","row","column")
);
--> statement-breakpoint
CREATE TABLE "queues" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"count" integer NOT NULL,
	"size" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "queue_items" (
	"id" text PRIMARY KEY NOT NULL,
	"order" integer NOT NULL,
	"queue_id" text NOT NULL,
	"value" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sync_endpoints" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text,
	"url" text,
	"group_id" text,
	"username" text,
	"password" text,
	"status" text
);
--> statement-breakpoint
CREATE TABLE "transactions" (
	"id" text PRIMARY KEY NOT NULL,
	"timestamp" text NOT NULL,
	"status" text DEFAULT 'Active' NOT NULL,
	"expiry" bigint
);
--> statement-breakpoint
CREATE TABLE "files" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"fieldname" text,
	"originalname" text,
	"encoding" text,
	"mimetype" text,
	"destination" text,
	"filename" text,
	"path" text,
	"size" integer,
	"uploaded_by" text,
	"downloaded_by" text,
	"etag" text,
	"versionId" text,
	"download_path" text
);
--> statement-breakpoint
CREATE TABLE "packets" (
	"id" uuid,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" timestamp with time zone NOT NULL,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"firewall_uuid" uuid,
	"network_interface" text,
	"mac_source" text,
	"mac_destination" text,
	"eth_type" text,
	"ip_version" integer,
	"header_length" integer,
	"total_length" integer,
	"protocol" text,
	"ip_source" text,
	"ip_destination" text,
	"source_port" integer,
	"destination_port" integer,
	"hypertable_timestamp" text,
	CONSTRAINT "packets_id_timestamp_pk" PRIMARY KEY("id","timestamp")
);
--> statement-breakpoint
CREATE TABLE "samples" (
	"id" text PRIMARY KEY NOT NULL,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" text,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"sample_text" text
);
--> statement-breakpoint
CREATE TABLE "temp_packets" (
	"id" uuid,
	"categories" text[] DEFAULT ARRAY[]::text[],
	"code" text,
	"tombstone" integer DEFAULT 0,
	"status" text DEFAULT 'Active',
	"version" integer DEFAULT 1,
	"created_date" text,
	"created_time" text,
	"updated_date" text,
	"updated_time" text,
	"organization_id" text DEFAULT (null),
	"created_by" text,
	"updated_by" text,
	"deleted_by" text,
	"requested_by" text,
	"timestamp" timestamp with time zone NOT NULL,
	"tags" text[] DEFAULT ARRAY[]::text[],
	"firewall_uuid" uuid,
	"network_interface" text,
	"mac_source" text,
	"mac_destination" text,
	"eth_type" text,
	"ip_version" integer,
	"header_length" integer,
	"total_length" integer,
	"protocol" text,
	"ip_source" text,
	"ip_destination" text,
	"source_port" integer,
	"destination_port" integer,
	"hypertable_timestamp" text,
	CONSTRAINT "temp_packets_id_pk" PRIMARY KEY("id")
);
--> statement-breakpoint
ALTER TABLE "config_sync" ADD CONSTRAINT "config_sync_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contact_emails" ADD CONSTRAINT "contact_emails_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contact_emails" ADD CONSTRAINT "contact_emails_contact_id_contacts_id_fk" FOREIGN KEY ("contact_id") REFERENCES "public"."contacts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contact_phone_numbers" ADD CONSTRAINT "contact_phone_numbers_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contact_phone_numbers" ADD CONSTRAINT "contact_phone_numbers_contact_id_contacts_id_fk" FOREIGN KEY ("contact_id") REFERENCES "public"."contacts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contacts" ADD CONSTRAINT "contacts_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "organization_contact_accounts" ADD CONSTRAINT "organization_contact_accounts_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "organization_contact_accounts" ADD CONSTRAINT "organization_contact_accounts_organization_contact_id_organization_contacts_id_fk" FOREIGN KEY ("organization_contact_id") REFERENCES "public"."organization_contacts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "organization_contacts" ADD CONSTRAINT "organization_contacts_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "organization_contacts" ADD CONSTRAINT "organization_contacts_contact_id_contacts_id_fk" FOREIGN KEY ("contact_id") REFERENCES "public"."contacts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "organization_domains" ADD CONSTRAINT "organization_domains_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "organization_files" ADD CONSTRAINT "organization_files_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "organization_files" ADD CONSTRAINT "organization_files_organizaion_id_organizations_id_fk" FOREIGN KEY ("organizaion_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "organization_files" ADD CONSTRAINT "organization_files_organization_contact_id_organization_contacts_id_fk" FOREIGN KEY ("organization_contact_id") REFERENCES "public"."organization_contacts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "organizations" ADD CONSTRAINT "organizations_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "organizations" ADD CONSTRAINT "organizations_parent_organization_id_organizations_id_fk" FOREIGN KEY ("parent_organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "config_applications" ADD CONSTRAINT "config_applications_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "class_types" ADD CONSTRAINT "class_types_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "fields" ADD CONSTRAINT "fields_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "allowed_fields" ADD CONSTRAINT "allowed_fields_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "allowed_fields" ADD CONSTRAINT "allowed_fields_class_type_id_class_types_id_fk" FOREIGN KEY ("class_type_id") REFERENCES "public"."class_types"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "files" ADD CONSTRAINT "files_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "packets" ADD CONSTRAINT "packets_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "samples" ADD CONSTRAINT "samples_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "temp_packets" ADD CONSTRAINT "temp_packets_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "config_sync_id_idx" ON "config_sync" USING btree ("id");--> statement-breakpoint
CREATE INDEX "config_sync_categories_idx" ON "config_sync" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "config_sync_code_idx" ON "config_sync" USING btree ("code");--> statement-breakpoint
CREATE INDEX "config_sync_tombstone_idx" ON "config_sync" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "config_sync_status_idx" ON "config_sync" USING btree ("status");--> statement-breakpoint
CREATE INDEX "config_sync_version_idx" ON "config_sync" USING btree ("version");--> statement-breakpoint
CREATE INDEX "config_sync_created_date_idx" ON "config_sync" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "config_sync_updated_date_idx" ON "config_sync" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "config_sync_organization_id_idx" ON "config_sync" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "config_sync_created_by_idx" ON "config_sync" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "config_sync_updated_by_idx" ON "config_sync" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "config_sync_deleted_by_idx" ON "config_sync" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "config_sync_requested_by_idx" ON "config_sync" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "config_sync_tags_idx" ON "config_sync" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "contact_emails_id_idx" ON "contact_emails" USING btree ("id");--> statement-breakpoint
CREATE INDEX "contact_emails_categories_idx" ON "contact_emails" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "contact_emails_code_idx" ON "contact_emails" USING btree ("code");--> statement-breakpoint
CREATE INDEX "contact_emails_tombstone_idx" ON "contact_emails" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "contact_emails_status_idx" ON "contact_emails" USING btree ("status");--> statement-breakpoint
CREATE INDEX "contact_emails_version_idx" ON "contact_emails" USING btree ("version");--> statement-breakpoint
CREATE INDEX "contact_emails_created_date_idx" ON "contact_emails" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "contact_emails_updated_date_idx" ON "contact_emails" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "contact_emails_organization_id_idx" ON "contact_emails" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "contact_emails_created_by_idx" ON "contact_emails" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "contact_emails_updated_by_idx" ON "contact_emails" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "contact_emails_deleted_by_idx" ON "contact_emails" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "contact_emails_requested_by_idx" ON "contact_emails" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "contact_emails_tags_idx" ON "contact_emails" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_id_idx" ON "contact_phone_numbers" USING btree ("id");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_categories_idx" ON "contact_phone_numbers" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_code_idx" ON "contact_phone_numbers" USING btree ("code");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_tombstone_idx" ON "contact_phone_numbers" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_status_idx" ON "contact_phone_numbers" USING btree ("status");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_version_idx" ON "contact_phone_numbers" USING btree ("version");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_created_date_idx" ON "contact_phone_numbers" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_updated_date_idx" ON "contact_phone_numbers" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_organization_id_idx" ON "contact_phone_numbers" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_created_by_idx" ON "contact_phone_numbers" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_updated_by_idx" ON "contact_phone_numbers" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_deleted_by_idx" ON "contact_phone_numbers" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_requested_by_idx" ON "contact_phone_numbers" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "contact_phone_numbers_tags_idx" ON "contact_phone_numbers" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "contacts_id_idx" ON "contacts" USING btree ("id");--> statement-breakpoint
CREATE INDEX "contacts_categories_idx" ON "contacts" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "contacts_code_idx" ON "contacts" USING btree ("code");--> statement-breakpoint
CREATE INDEX "contacts_tombstone_idx" ON "contacts" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "contacts_status_idx" ON "contacts" USING btree ("status");--> statement-breakpoint
CREATE INDEX "contacts_version_idx" ON "contacts" USING btree ("version");--> statement-breakpoint
CREATE INDEX "contacts_created_date_idx" ON "contacts" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "contacts_updated_date_idx" ON "contacts" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "contacts_organization_id_idx" ON "contacts" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "contacts_created_by_idx" ON "contacts" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "contacts_updated_by_idx" ON "contacts" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "contacts_deleted_by_idx" ON "contacts" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "contacts_requested_by_idx" ON "contacts" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "contacts_tags_idx" ON "contacts" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_id_idx" ON "organization_contact_accounts" USING btree ("id");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_categories_idx" ON "organization_contact_accounts" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_code_idx" ON "organization_contact_accounts" USING btree ("code");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_tombstone_idx" ON "organization_contact_accounts" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_status_idx" ON "organization_contact_accounts" USING btree ("status");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_version_idx" ON "organization_contact_accounts" USING btree ("version");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_created_date_idx" ON "organization_contact_accounts" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_updated_date_idx" ON "organization_contact_accounts" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_organization_id_idx" ON "organization_contact_accounts" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_created_by_idx" ON "organization_contact_accounts" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_updated_by_idx" ON "organization_contact_accounts" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_deleted_by_idx" ON "organization_contact_accounts" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_requested_by_idx" ON "organization_contact_accounts" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "organization_contact_accounts_tags_idx" ON "organization_contact_accounts" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "organization_contacts_id_idx" ON "organization_contacts" USING btree ("id");--> statement-breakpoint
CREATE INDEX "organization_contacts_categories_idx" ON "organization_contacts" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "organization_contacts_code_idx" ON "organization_contacts" USING btree ("code");--> statement-breakpoint
CREATE INDEX "organization_contacts_tombstone_idx" ON "organization_contacts" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "organization_contacts_status_idx" ON "organization_contacts" USING btree ("status");--> statement-breakpoint
CREATE INDEX "organization_contacts_version_idx" ON "organization_contacts" USING btree ("version");--> statement-breakpoint
CREATE INDEX "organization_contacts_created_date_idx" ON "organization_contacts" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "organization_contacts_updated_date_idx" ON "organization_contacts" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "organization_contacts_organization_id_idx" ON "organization_contacts" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "organization_contacts_created_by_idx" ON "organization_contacts" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "organization_contacts_updated_by_idx" ON "organization_contacts" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "organization_contacts_deleted_by_idx" ON "organization_contacts" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "organization_contacts_requested_by_idx" ON "organization_contacts" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "organization_contacts_tags_idx" ON "organization_contacts" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "organization_domains_id_idx" ON "organization_domains" USING btree ("id");--> statement-breakpoint
CREATE INDEX "organization_domains_categories_idx" ON "organization_domains" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "organization_domains_code_idx" ON "organization_domains" USING btree ("code");--> statement-breakpoint
CREATE INDEX "organization_domains_tombstone_idx" ON "organization_domains" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "organization_domains_status_idx" ON "organization_domains" USING btree ("status");--> statement-breakpoint
CREATE INDEX "organization_domains_version_idx" ON "organization_domains" USING btree ("version");--> statement-breakpoint
CREATE INDEX "organization_domains_created_date_idx" ON "organization_domains" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "organization_domains_updated_date_idx" ON "organization_domains" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "organization_domains_organization_id_idx" ON "organization_domains" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "organization_domains_created_by_idx" ON "organization_domains" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "organization_domains_updated_by_idx" ON "organization_domains" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "organization_domains_deleted_by_idx" ON "organization_domains" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "organization_domains_requested_by_idx" ON "organization_domains" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "organization_domains_tags_idx" ON "organization_domains" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "organization_files_id_idx" ON "organization_files" USING btree ("id");--> statement-breakpoint
CREATE INDEX "organization_files_categories_idx" ON "organization_files" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "organization_files_code_idx" ON "organization_files" USING btree ("code");--> statement-breakpoint
CREATE INDEX "organization_files_tombstone_idx" ON "organization_files" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "organization_files_status_idx" ON "organization_files" USING btree ("status");--> statement-breakpoint
CREATE INDEX "organization_files_version_idx" ON "organization_files" USING btree ("version");--> statement-breakpoint
CREATE INDEX "organization_files_created_date_idx" ON "organization_files" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "organization_files_updated_date_idx" ON "organization_files" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "organization_files_organization_id_idx" ON "organization_files" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "organization_files_created_by_idx" ON "organization_files" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "organization_files_updated_by_idx" ON "organization_files" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "organization_files_deleted_by_idx" ON "organization_files" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "organization_files_requested_by_idx" ON "organization_files" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "organization_files_tags_idx" ON "organization_files" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "organizations_id_idx" ON "organizations" USING btree ("id");--> statement-breakpoint
CREATE INDEX "organizations_categories_idx" ON "organizations" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "organizations_code_idx" ON "organizations" USING btree ("code");--> statement-breakpoint
CREATE INDEX "organizations_tombstone_idx" ON "organizations" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "organizations_status_idx" ON "organizations" USING btree ("status");--> statement-breakpoint
CREATE INDEX "organizations_version_idx" ON "organizations" USING btree ("version");--> statement-breakpoint
CREATE INDEX "organizations_created_date_idx" ON "organizations" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "organizations_updated_date_idx" ON "organizations" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "organizations_organization_id_idx" ON "organizations" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "organizations_created_by_idx" ON "organizations" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "organizations_updated_by_idx" ON "organizations" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "organizations_deleted_by_idx" ON "organizations" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "organizations_requested_by_idx" ON "organizations" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "organizations_tags_idx" ON "organizations" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "config_applications_id_idx" ON "config_applications" USING btree ("id");--> statement-breakpoint
CREATE INDEX "config_applications_categories_idx" ON "config_applications" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "config_applications_code_idx" ON "config_applications" USING btree ("code");--> statement-breakpoint
CREATE INDEX "config_applications_tombstone_idx" ON "config_applications" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "config_applications_status_idx" ON "config_applications" USING btree ("status");--> statement-breakpoint
CREATE INDEX "config_applications_version_idx" ON "config_applications" USING btree ("version");--> statement-breakpoint
CREATE INDEX "config_applications_created_date_idx" ON "config_applications" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "config_applications_updated_date_idx" ON "config_applications" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "config_applications_organization_id_idx" ON "config_applications" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "config_applications_created_by_idx" ON "config_applications" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "config_applications_updated_by_idx" ON "config_applications" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "config_applications_deleted_by_idx" ON "config_applications" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "config_applications_requested_by_idx" ON "config_applications" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "config_applications_tags_idx" ON "config_applications" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "class_types_id_idx" ON "class_types" USING btree ("id");--> statement-breakpoint
CREATE INDEX "class_types_categories_idx" ON "class_types" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "class_types_code_idx" ON "class_types" USING btree ("code");--> statement-breakpoint
CREATE INDEX "class_types_tombstone_idx" ON "class_types" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "class_types_status_idx" ON "class_types" USING btree ("status");--> statement-breakpoint
CREATE INDEX "class_types_version_idx" ON "class_types" USING btree ("version");--> statement-breakpoint
CREATE INDEX "class_types_created_date_idx" ON "class_types" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "class_types_updated_date_idx" ON "class_types" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "class_types_organization_id_idx" ON "class_types" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "class_types_created_by_idx" ON "class_types" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "class_types_updated_by_idx" ON "class_types" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "class_types_deleted_by_idx" ON "class_types" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "class_types_requested_by_idx" ON "class_types" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "class_types_tags_idx" ON "class_types" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "fields_id_idx" ON "fields" USING btree ("id");--> statement-breakpoint
CREATE INDEX "fields_categories_idx" ON "fields" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "fields_code_idx" ON "fields" USING btree ("code");--> statement-breakpoint
CREATE INDEX "fields_tombstone_idx" ON "fields" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "fields_status_idx" ON "fields" USING btree ("status");--> statement-breakpoint
CREATE INDEX "fields_version_idx" ON "fields" USING btree ("version");--> statement-breakpoint
CREATE INDEX "fields_created_date_idx" ON "fields" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "fields_updated_date_idx" ON "fields" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "fields_organization_id_idx" ON "fields" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "fields_created_by_idx" ON "fields" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "fields_updated_by_idx" ON "fields" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "fields_deleted_by_idx" ON "fields" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "fields_requested_by_idx" ON "fields" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "fields_tags_idx" ON "fields" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "allowed_fields_id_idx" ON "allowed_fields" USING btree ("id");--> statement-breakpoint
CREATE INDEX "allowed_fields_categories_idx" ON "allowed_fields" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "allowed_fields_code_idx" ON "allowed_fields" USING btree ("code");--> statement-breakpoint
CREATE INDEX "allowed_fields_tombstone_idx" ON "allowed_fields" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "allowed_fields_status_idx" ON "allowed_fields" USING btree ("status");--> statement-breakpoint
CREATE INDEX "allowed_fields_version_idx" ON "allowed_fields" USING btree ("version");--> statement-breakpoint
CREATE INDEX "allowed_fields_created_date_idx" ON "allowed_fields" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "allowed_fields_updated_date_idx" ON "allowed_fields" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "allowed_fields_organization_id_idx" ON "allowed_fields" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "allowed_fields_created_by_idx" ON "allowed_fields" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "allowed_fields_updated_by_idx" ON "allowed_fields" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "allowed_fields_deleted_by_idx" ON "allowed_fields" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "allowed_fields_requested_by_idx" ON "allowed_fields" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "allowed_fields_tags_idx" ON "allowed_fields" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "files_id_idx" ON "files" USING btree ("id");--> statement-breakpoint
CREATE INDEX "files_categories_idx" ON "files" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "files_code_idx" ON "files" USING btree ("code");--> statement-breakpoint
CREATE INDEX "files_tombstone_idx" ON "files" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "files_status_idx" ON "files" USING btree ("status");--> statement-breakpoint
CREATE INDEX "files_version_idx" ON "files" USING btree ("version");--> statement-breakpoint
CREATE INDEX "files_created_date_idx" ON "files" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "files_updated_date_idx" ON "files" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "files_organization_id_idx" ON "files" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "files_created_by_idx" ON "files" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "files_updated_by_idx" ON "files" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "files_deleted_by_idx" ON "files" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "files_requested_by_idx" ON "files" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "files_tags_idx" ON "files" USING btree ("tags");--> statement-breakpoint
CREATE INDEX "samples_id_idx" ON "samples" USING btree ("id");--> statement-breakpoint
CREATE INDEX "samples_categories_idx" ON "samples" USING btree ("categories");--> statement-breakpoint
CREATE INDEX "samples_code_idx" ON "samples" USING btree ("code");--> statement-breakpoint
CREATE INDEX "samples_tombstone_idx" ON "samples" USING btree ("tombstone");--> statement-breakpoint
CREATE INDEX "samples_status_idx" ON "samples" USING btree ("status");--> statement-breakpoint
CREATE INDEX "samples_version_idx" ON "samples" USING btree ("version");--> statement-breakpoint
CREATE INDEX "samples_created_date_idx" ON "samples" USING btree ("created_date");--> statement-breakpoint
CREATE INDEX "samples_updated_date_idx" ON "samples" USING btree ("updated_date");--> statement-breakpoint
CREATE INDEX "samples_organization_id_idx" ON "samples" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "samples_created_by_idx" ON "samples" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "samples_updated_by_idx" ON "samples" USING btree ("updated_by");--> statement-breakpoint
CREATE INDEX "samples_deleted_by_idx" ON "samples" USING btree ("deleted_by");--> statement-breakpoint
CREATE INDEX "samples_requested_by_idx" ON "samples" USING btree ("requested_by");--> statement-breakpoint
CREATE INDEX "samples_tags_idx" ON "samples" USING btree ("tags");