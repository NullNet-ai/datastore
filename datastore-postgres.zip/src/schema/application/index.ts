// define the schema for the application
export { table as samples } from '../application/samples';
export { table as files } from '../application/files';
export { table as packets } from '../application/packets'; //hypertable
export { table as temp_packets } from '../application/temp_packets';
